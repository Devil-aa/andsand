from django.apps import AppConfig


class InpformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inpform'
